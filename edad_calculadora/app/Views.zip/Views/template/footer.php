<html>
    <body>
        <footer style="background-color: #60acbd;">
            <h4>Creado por JIGS</h4>
            <p>Hola Mundo! en CI4</p>
        </footer>
    </body>

</html>