<?php view('template/header'); ?>
<div>Tu edad es <?php echo $edad ?></div>
<?php view('template/footer'); ?>